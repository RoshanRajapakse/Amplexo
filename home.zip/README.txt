
TITLE: 
Slides - Responsive Free HTML5 Horizontal Slides Template

AUTHOR:
DESIGNED & DEVELOPED by FreeHTML5.co and Designmodo.com

Website: http://freehtml5.co/
Twitter: http://twitter.com/fh5co
Facebook: http://facebook.com/fh5co


CREDITS:

jQuery
http://jquery.com/

Google Fonts
https://www.google.com/fonts/
